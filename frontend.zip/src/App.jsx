import React from 'react'
import Routers from './routers/components/Routers'

const App = () => {
  return <Routers/>
}

export default App
