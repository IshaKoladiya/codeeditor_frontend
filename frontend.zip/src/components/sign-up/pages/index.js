import React from "react"

const SignUp = React.lazy(()=>import("../components/SignUp"))

export {SignUp}