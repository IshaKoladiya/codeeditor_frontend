import React from "react"

const Login = React.lazy(()=>import("../components/Login"))

export { Login }